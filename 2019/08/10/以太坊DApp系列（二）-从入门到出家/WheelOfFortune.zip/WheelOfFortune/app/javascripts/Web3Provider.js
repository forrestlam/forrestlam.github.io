Web3 = require('web3');

// module.exports = new Web3.providers.HttpProvider("http://localhost:8545");
module.exports = new Web3.providers.HttpProvider("https://ropsten.infura.io/Fk6TkgXxOYX9dEbI4krn/");