//
//  ViewController.swift
//  mldemo
//
//  Created by forrestlin on 2018/8/19.
//  Copyright © 2018年 forrestlin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var realLabel: UILabel!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var x3TextField: UITextField!
    @IBOutlet weak var x2TextFied: UITextField!
    @IBOutlet weak var x1TextField: UITextField!
    let linearRegression = linear_regression()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func onPredictClicked(_ sender: Any) {
        let x1 = Double.init(x1TextField.text ?? "0") ?? 0.0
        let x2 = Double.init(x2TextFied.text ?? "0") ?? 0.0
        let x3 = Double.init(x3TextField.text ?? "0") ?? 0.0
        guard let resultOutput = try? linearRegression.prediction(x1: x1, x2: x2, x3: x3) else {
            fatalError("Unexpected runtime error.")
        }
        resultLabel.text = "预测结果：\(String.init(format: "%.3f", resultOutput.y))"
        // 0.88388580559328,0.9739076282633957,0.26285257992475464,0.06368572997936028
        realLabel.text = "真实结果：\(String.init(format: "%.3f", x1 * 0.88388580559328 + x2 * 0.9739076282633957 + x3 * 0.26285257992475464 + 0.06368572997936028))"
    }
    

}

